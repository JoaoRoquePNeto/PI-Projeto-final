from django import forms
from .models import *

class FormularioMaterial(forms.ModelForm):
  class Meta:
    model = Material
    fields = ["nome", "fabricante", "codigo", "emprestado", "apresenta_defeito", "disponivel_emprestimo", "observacao", "categoria"]
    labels = {
    "nome": "Nome", 
    "fabricante": "Fabricante",
    "codigo": "Código",
    "emprestado": "Emprestado",
    "apresenta_defeito": "Apresenta defeito?", 
    "disponivel_emprestimo": "Disponivel para Emprestimo",
    "observacao": "Observações",
    "categoria": "Categoria"
    }

class FormularioUsuario(forms.ModelForm):
  class Meta:
    model = Usuario
    fields = ["nome", "funcao", "email", "telefone", "matricula", "senha"]
    labels = {
      "nome" : "Nome",
      "funcao" : "Função",
      "email" : "Email",
      "telefone" : "Telefone",
      "matricula" : "Material",
      "senha" : "Senha",
    }

class FormularioLocatario(forms.ModelForm):
  class Meta:
    model = Locatario
    fields = ["nome", "email", "telefone", "matricula", "endereco", "cidade"]
    labels = {
      "nome" : "Nome",
      "email" : "Email",
      "telefone" : "Telefone",
      "matricula" : "Matricula",
      "endereco" : "Endereco",
      "cidade" : "Cidade",
    }

class FormularioCidade(forms.ModelForm):
  class Meta:
    model = Cidade
    fields = ["nome"]
    labels = {
      "nome" : "Nome",
    }
