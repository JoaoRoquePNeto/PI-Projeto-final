
# Create your views here.
from django.shortcuts import render, redirect
from principal.models import *
from django.contrib import messages
from django.contrib.messages import constants
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout




def logout_app(request):
  logout(request)
  return redirect('login')

@login_required
def index(request):
  lista = Categoria.objects.all()
  context={'categorias' : lista}
  return render(request, "index.html", context)

@login_required
def disponiveis(request):
  return render(request, "disponiveis.html")  

@login_required
def novoEmprestimo(request):
  return render(request, "novoEmprestimo.html")

@login_required
def indisponiveis(request):
  return render(request, "indisponiveis.html")  

@login_required
def emprestar(request):
  return render(request, "emprestar.html")

@login_required
def instruteclas(request, id):
  lista = Material.objects.filter(categoria = id)
  context={'materiais' : lista}
  return render(request, "instruteclas.html", context)    

@login_required
def detalhesteclas(request):
  return render(request, "detalhesteclas.html")     

@login_required
def cadastetclas(request):
  if request.method == "GET":
    cotegorias = Categoria.objects.all()
    return render(request, "cadastetclas.html", {'categorias': cotegorias})
  elif request.method == "POST":
    nome = request.POST.get("nome")
    fabricante = request.POST.get("fabricante")
    codigo = request.POST.get("codigo")
    emprestado = request.POST.get("emprestado")
    apresenta_defeito = request.POST.get("apresenta_defeito")
    disponivel_emprestimo = request.POST.get("disponivel_emprestimo")
    observacao = request.POST.get("observacao")
    categoria = request.POST.get("categoria")

    if (len(nome.strip()) == 0 or len(fabricante.strip()) == 0 or len(codigo.strip()) == 0):
      messages.add_message(request, constants.ERROR, 'Preencha todos os campos')
      return redirect('/cadastetclas')

  def changeType(value):
    if value == 'on':
      return True
    else:
      return False

  material = Material(nome=nome, fabricante=fabricante, codigo=codigo, emprestado=changeType(emprestado), apresenta_defeito=changeType(apresenta_defeito), disponivel_emprestimo=changeType(disponivel_emprestimo), observacao=observacao)
  material.categoria = Categoria(id=categoria)
  material.save()

  return redirect('/')

@login_required
def cadastrarusuario(request):
  if request.method == "GET":
    funcoes = Funcao.objects.all()
    return render(request, "cadastrarusuario.html", {'funcoes': funcoes})
  elif request.method == "POST":
    nome = request.POST.get('nome')
    email = request.POST.get('email')
    telefone = request.POST.get('telefone')   
    matricula = request.POST.get('matricula')
    senha = request.POST.get('senha')
    funcao = request.POST.get('funcao')

    if (len(nome.strip()) == 0 or len(email.strip()) == 0 or len(telefone.strip()) == 0 
    or len(matricula.strip()) == 0 or len(senha.strip()) == 0 or len(funcao.strip()) == 0):
      messages.add_message(request, constants.ERROR, 'Preencha todos os campos')
      return redirect('/cadastrarusuario')

    usuario = Usuario(nome=nome, email=email, telefone=telefone, matricula=matricula, senha=senha)
    usuario.funcao = Funcao(id=funcao)
    usuario.save()

    return redirect("/")

@login_required
def cadastropessoas(request):
  if request.method == "GET":
    cidades = Cidade.objects.all()
    return render(request, "cadastropessoas.html", {'cidades': cidades})
  elif request.method == "POST":
    nome = request.POST.get('nome')
    email = request.POST.get('email')
    cidade = request.POST.get('cidade')
    endereco = request.POST.get('endereco')
    matricula = request.POST.get('matricula')
    telefone = request.POST.get('telefone')

    if (len(nome.strip()) == 0 or len(email.strip()) == 0 or len(cidade.strip()) == 0 or len(endereco.strip()) == 0 
    or len(matricula.strip()) == 0 or len(telefone.strip()) == 0 ): 
      messages.add_message(request, constants.ERROR, 'Preencha todos os campos')
      return redirect('/cadastropessoas')

    locatario = Locatario(nome=nome, email=email, endereco=endereco, matricula=matricula, telefone=telefone)
    locatario.cidade = Cidade(id=cidade)
    locatario.save()
    messages.add_message(request, constants.SUCCESS, 'Cadastro completo')
    return redirect('/novoEmprestimo') 