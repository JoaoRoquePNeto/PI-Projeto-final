# Create your models here.
from ftplib import MAXLINE
from unittest.util import _MAX_LENGTH
from django.db import models

class Funcao (models.Model):
  funcao = models.CharField(max_length=100)

  def __str__(self) -> str:
     return self.funcao

class Cidade (models.Model):
  nome = models.CharField(max_length = 100)

  def __str__(self) -> str:
    return self.nome

class Usuario (models.Model):
    nome = models.CharField(max_length = 100)
    email = models.EmailField()
    telefone = models.CharField(max_length = 50)
    matricula = models.CharField(max_length = 80)
    senha = models.CharField(max_length = 100)
    funcao = models.ForeignKey(Funcao, on_delete=models.CASCADE)
    def __str__(self) -> str:
      return self.nome

class Login (models.Model):
  matricula = models.CharField(max_length = 100)
  senha = models.CharField(max_length = 50)

  def __str__(self) -> str:
      return self.nome

class Locatario (models.Model):
    nome = models.CharField(max_length = 100)
    email = models.EmailField()
    telefone = models.CharField(max_length = 11)
    matricula = models.CharField(max_length = 100)
    endereco = models.CharField(max_length = 100)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return self.nome

class Categoria (models.Model):
    nome = models.CharField(max_length = 100)
    imagem = models.ImageField(upload_to='categoria/', blank=True, null=True, max_length=250)

    def __str__(self) -> str:
        return self.nome

class Material (models.Model):
  nome = models.CharField(max_length = 150)
  fabricante = models.CharField(max_length = 150)
  codigo = models.CharField(max_length = 10)
  emprestado = models.BooleanField(null=True)
  apresenta_defeito = models.BooleanField(null=True)
  disponivel_emprestimo = models.BooleanField(null=True)
  observacao = models.TextField(null=True)
  categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)

  def __str__(self) -> str:
    return self.nome

class Emprestimo (models.Model):

  observacao = models.CharField(max_length = 150)
  data = models.DateField() 
  material = models.ForeignKey(Material, on_delete=models.CASCADE)
  locatario = models.ForeignKey(Locatario, on_delete=models.CASCADE)

  def __str__(self) -> str:
    return self.nome