from django.contrib import admin
from .models import *

class UsuarioAdmin(admin.ModelAdmin):
    list_display = ('id', 'nome', 'funcao', 'matricula')
    
class MaterialAdmin(admin.ModelAdmin):
    list_display = ('id', 'nome', 'codigo', 'emprestado', 'apresenta_defeito', 'disponivel_emprestimo')

admin.site.register(Usuario,UsuarioAdmin)
admin.site.register(Categoria)
admin.site.register(Locatario)
admin.site.register(Funcao)
admin.site.register(Material, MaterialAdmin)
admin.site.register(Cidade)